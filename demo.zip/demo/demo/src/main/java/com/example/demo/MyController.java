package com.example.demo;

import java.time.Duration;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Mono;

@RestController
public class MyController {
	
	static int count=0;
	
	@GetMapping("/hello")
	public Mono<String> greetingMessage(){
		return computeMessage().zipWith(getNameFromDb())
		.map(value->value.getT1()+value.getT2());
		
	}
	
	private Mono<String> computeMessage() {
		
		return Mono.just("Hello..."+String.valueOf(++count)).delayElement(Duration.ofSeconds(3));
	}
	
	private Mono<String> getNameFromDb(){
		return Mono.just("Narendra").delayElement(Duration.ofSeconds(3));
	}
}
